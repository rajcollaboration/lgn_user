import React from 'react'

const Predictions = () => {
  return (
    <div>Predictions</div>
  )
}

export default Predictions